import React from 'react';
import { Link } from 'react-router-dom';
const DashboardLayout = ({ children }) => {
  return (
    <div className="min-h-screen bg-background flex text-white font-sans">
      {/* Sidebar Placeholder */}
      <aside className="w-64 border-r border-white/10 hidden md:block flex-shrink-0 bg-surface/50">
        <div className="p-6">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-accent to-primary-500 bg-clip-text text-transparent">
            EduGen AI
          </h1>
        </div>
        <nav className="px-4 mt-6 flex flex-col gap-2">
          {/* Nav Items */}
          <Link to="/" className="px-4 py-3 rounded-lg text-slate-400 hover:bg-white/5 hover:text-white transition-colors block">Dashboard</Link>
          <Link to="/documents" className="px-4 py-3 rounded-lg text-slate-400 hover:bg-white/5 hover:text-white transition-colors block">Library</Link>
          <Link to="/tutor" className="px-4 py-3 rounded-lg text-slate-400 hover:bg-white/5 hover:text-white transition-colors block">AI Tutor</Link>
          <Link to="/quizzes" className="px-4 py-3 rounded-lg text-slate-400 hover:bg-white/5 hover:text-white transition-colors block">Quizzes</Link>
          <Link to="/flashcards" className="px-4 py-3 rounded-lg text-slate-400 hover:bg-white/5 hover:text-white transition-colors block">Flashcards</Link>
          <Link to="/study-plans" className="px-4 py-3 rounded-lg text-slate-400 hover:bg-white/5 hover:text-white transition-colors block">Study Plans</Link>
          <Link to="/coding-coach" className="px-4 py-3 rounded-lg text-slate-400 hover:bg-white/5 hover:text-white transition-colors block">Coding Coach</Link>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        <header className="h-20 border-b border-white/10 px-8 flex items-center justify-between sticky top-0 bg-background/80 backdrop-blur-md z-10">
          <h2 className="text-xl font-semibold">Overview</h2>
          <div className="flex items-center gap-4">
            <div className="h-10 w-10 rounded-full bg-primary-600 flex items-center justify-center font-bold shadow-lg shadow-primary-500/20 cursor-pointer">
              U
            </div>
          </div>
        </header>
        <div className="p-8 overflow-y-auto">
          {children || (
             <div className="glass-panel p-8">
               <h3 className="text-xl font-medium mb-4">Welcome back, Student!</h3>
               <p className="text-slate-400">Your AI learning journey continues here.</p>
             </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default DashboardLayout;
