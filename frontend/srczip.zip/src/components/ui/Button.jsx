import React from 'react';

const Button = ({ children, onClick, type = 'button', variant = 'primary', className = '', ...props }) => {
  const baseStyle = "px-6 py-2.5 rounded-lg font-medium transition-all duration-200 transform hover:scale-[1.02] active:scale-95 flex items-center justify-center";
  
  const variants = {
    primary: "bg-primary-600 hover:bg-primary-500 text-white shadow-lg shadow-primary-500/30",
    secondary: "bg-surface hover:bg-slate-700 text-white border border-slate-600",
    ghost: "hover:bg-white/10 text-slate-300 hover:text-white"
  };

  return (
    <button
      type={type}
      onClick={onClick}
      className={`${baseStyle} ${variants[variant]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};

export default Button;
