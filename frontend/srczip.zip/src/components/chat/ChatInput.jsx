import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, BookOpen, BrainCircuit, Code, List, X } from 'lucide-react';

const QUICK_ACTIONS = [
  { label: 'Explain Simpler', icon: <Sparkles size={14} /> },
  { label: 'Quiz', icon: <BookOpen size={14} /> },
  { label: 'Mind Map', icon: <BrainCircuit size={14} /> },
  { label: 'Coding Example', icon: <Code size={14} /> },
  { label: 'Notes', icon: <List size={14} /> },
];

const ChatInput = ({ onSend, disabled }) => {
  const [message, setMessage] = useState('');
  const [showQuizModal, setShowQuizModal] = useState(false);
  const [quizConfig, setQuizConfig] = useState({
    quizType: 'mixed',
    difficulty: 'medium',
    numQuestions: 10
  });

  const textareaRef = useRef(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [message]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (message.trim() && !disabled) {
      onSend(message, null);
      setMessage('');
      if (textareaRef.current) textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleAction = (actionLabel) => {
    if (disabled) return;
    
    if (actionLabel === 'Quiz') {
      setShowQuizModal(true);
      return;
    }

    onSend(message || `Please provide a ${actionLabel.toLowerCase()} for the current topic.`, actionLabel);
    setMessage('');
  };

  const submitQuizRequest = () => {
    onSend(message || 'Please generate a quiz for the current topic.', 'Quiz', quizConfig);
    setShowQuizModal(false);
    setMessage('');
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 md:px-8 pb-6 pt-2 relative">
      
      {/* Quiz Config Modal */}
      {showQuizModal && (
        <div className="absolute bottom-full left-0 mb-4 ml-4 md:ml-8 p-4 bg-white dark:bg-dark-surface border border-gray-200 dark:border-slate-700 rounded-xl shadow-xl z-50 w-80 animate-fade-in">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-sm">Configure Quiz</h3>
            <button onClick={() => setShowQuizModal(false)} className="text-slate-500 hover:text-slate-700 dark:hover:text-slate-300">
              <X size={16} />
            </button>
          </div>
          
          <div className="space-y-3 text-sm">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Quiz Type</label>
              <select 
                value={quizConfig.quizType} 
                onChange={(e) => setQuizConfig({...quizConfig, quizType: e.target.value})}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 focus:ring-1 focus:ring-primary"
              >
                <option value="mixed">Mixed Quiz (Default)</option>
                <option value="mcq">Multiple Choice (MCQ)</option>
                <option value="true_false">True / False</option>
                <option value="fill_blank">Fill in the Blanks</option>
                <option value="short_answer">Short Answer</option>
              </select>
            </div>
            
            <div className="flex gap-2">
              <div className="flex-1">
                <label className="block text-xs font-medium text-slate-500 mb-1">Difficulty</label>
                <select 
                  value={quizConfig.difficulty} 
                  onChange={(e) => setQuizConfig({...quizConfig, difficulty: e.target.value})}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 focus:ring-1 focus:ring-primary"
                >
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                </select>
              </div>
              
              <div className="flex-1">
                <label className="block text-xs font-medium text-slate-500 mb-1">Questions</label>
                <select 
                  value={quizConfig.numQuestions} 
                  onChange={(e) => setQuizConfig({...quizConfig, numQuestions: parseInt(e.target.value)})}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 focus:ring-1 focus:ring-primary"
                >
                  <option value={5}>5 Questions</option>
                  <option value={10}>10 Questions</option>
                  <option value={20}>20 Questions</option>
                </select>
              </div>
            </div>
            
            <button 
              onClick={submitQuizRequest}
              className="w-full mt-2 bg-primary text-white py-2 rounded-lg font-medium hover:bg-primary-dark transition-colors"
            >
              Generate Quiz
            </button>
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div className="flex flex-wrap gap-2 mb-3 px-2">
        {QUICK_ACTIONS.map((action) => (
          <button
            key={action.label}
            onClick={() => handleAction(action.label)}
            disabled={disabled}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium 
                     bg-white dark:bg-dark-surface border border-gray-200 dark:border-slate-700 
                     text-slate-600 dark:text-slate-300 hover:border-primary dark:hover:border-primary 
                     hover:text-primary dark:hover:text-primary transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-sm"
          >
            {action.icon}
            {action.label}
          </button>
        ))}
      </div>

      {/* Input Area */}
      <form onSubmit={handleSubmit} className="relative group">
        <div className="glass-panel overflow-hidden transition-shadow focus-within:ring-2 focus-within:ring-primary/50 focus-within:border-primary">
          <textarea
            ref={textareaRef}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={disabled}
            placeholder="Ask your AI Tutor anything..."
            className="w-full max-h-[200px] min-h-[56px] py-4 pl-4 pr-12 bg-transparent text-light-text dark:text-dark-text placeholder-slate-400 focus:outline-none resize-none custom-scrollbar"
            rows={1}
          />
          <button
            type="submit"
            disabled={!message.trim() || disabled}
            className="absolute bottom-3 right-3 p-2 rounded-xl bg-primary text-white hover:bg-primary-dark disabled:bg-slate-300 dark:disabled:bg-slate-700 disabled:text-slate-500 transition-colors shadow-sm flex items-center justify-center"
          >
            <Send size={18} className={message.trim() && !disabled ? 'ml-0.5' : ''} />
          </button>
        </div>
        <div className="text-center mt-2">
          <span className="text-[10px] text-slate-400 dark:text-slate-500">
            AI Tutor can make mistakes. Consider verifying important information.
          </span>
        </div>
      </form>
    </div>
  );
};

export default ChatInput;
