import React from 'react';

const TopicsWidget = ({ title, topics }) => {
  return (
    <div className="glass-panel p-6 flex flex-col h-full">
      <h3 className="text-lg font-semibold text-white mb-6">{title}</h3>
      
      <div className="flex flex-col gap-5 flex-1">
        {topics.map((topic, index) => (
          <div key={index}>
            <div className="flex justify-between text-sm mb-1.5">
              <span className="font-medium text-slate-300">{topic.name}</span>
              <span className="text-slate-400">{topic.score}%</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-2">
              <div 
                className={`h-2 rounded-full ${
                  topic.score > 70 ? 'bg-green-500' : topic.score > 40 ? 'bg-amber-500' : 'bg-red-500'
                }`}
                style={{ width: `${topic.score}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TopicsWidget;
