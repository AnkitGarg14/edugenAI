import React from 'react';

const StatCard = ({ title, value, subtitle, icon: Icon, trend, trendValue, color = 'primary' }) => {
  const trendColor = trend === 'up' ? 'text-green-400' : trend === 'down' ? 'text-red-400' : 'text-slate-400';
  
  return (
    <div className="glass-panel p-6 flex flex-col relative overflow-hidden group">
      {/* Decorative gradient blob */}
      <div className={`absolute -right-10 -top-10 w-32 h-32 bg-${color}-500/10 rounded-full blur-2xl group-hover:bg-${color}-500/20 transition-all duration-500`} />
      
      <div className="flex justify-between items-start mb-4 relative z-10">
        <div>
          <h3 className="text-slate-400 font-medium text-sm">{title}</h3>
          <div className="flex items-end gap-2 mt-1">
            <span className="text-3xl font-bold text-white">{value}</span>
            {subtitle && <span className="text-sm text-slate-500 mb-1">{subtitle}</span>}
          </div>
        </div>
        {Icon && (
          <div className={`p-3 rounded-xl bg-${color}-500/20 text-${color}-400`}>
            <Icon size={24} />
          </div>
        )}
      </div>
      
      {trendValue && (
        <div className="flex items-center gap-1 mt-auto relative z-10">
          <span className={`text-xs font-semibold ${trendColor}`}>
            {trend === 'up' ? '+' : trend === 'down' ? '-' : ''}{trendValue}
          </span>
          <span className="text-xs text-slate-500">vs last week</span>
        </div>
      )}
    </div>
  );
};

export default StatCard;
