import React from 'react';
import { ArrowRight } from 'lucide-react';

const ListWidget = ({ title, items, onViewAll }) => {
  return (
    <div className="glass-panel p-6 flex flex-col h-full">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-semibold text-white">{title}</h3>
        {onViewAll && (
          <button onClick={onViewAll} className="text-sm text-accent hover:text-primary-400 flex items-center gap-1 transition-colors">
            View All <ArrowRight size={14} />
          </button>
        )}
      </div>

      <div className="flex flex-col gap-4 flex-1">
        {items.map((item, index) => {
          const Icon = item.icon;
          return (
            <div key={index} className="flex items-center gap-4 group cursor-pointer hover:bg-white/5 p-2 rounded-lg transition-colors -mx-2">
              <div className={`p-2.5 rounded-lg ${item.colorClass || 'bg-slate-800 text-slate-300'}`}>
                {Icon && <Icon size={18} />}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-medium text-slate-200 truncate group-hover:text-white">{item.title}</h4>
                <p className="text-xs text-slate-500 truncate">{item.subtitle}</p>
              </div>
              {item.rightContent && (
                <div className="text-xs font-medium text-slate-400 whitespace-nowrap">
                  {item.rightContent}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ListWidget;
