import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../services/api';
import toast from 'react-hot-toast';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';
import { ArrowLeft } from 'lucide-react';

const ForgotPasswordPage = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post('/auth/forgot-password', { email });
      setSent(true);
      toast.success('Reset link sent to your email');
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to send reset link');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col w-full">
      <Link to="/login" className="flex items-center text-sm text-slate-400 hover:text-white mb-6 w-fit transition-colors">
        <ArrowLeft className="w-4 h-4 mr-2" /> Back to login
      </Link>
      
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Forgot Password</h2>
        <p className="text-slate-400">Enter your email and we'll send you a link to reset your password.</p>
      </div>

      {!sent ? (
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <Input 
            label="Email Address" 
            type="email" 
            placeholder="Enter your email" 
            value={email} 
            onChange={(e) => setEmail(e.target.value)} 
            required 
          />
          <Button type="submit" variant="primary" className="w-full mt-4" disabled={loading}>
            {loading ? 'Sending...' : 'Send Reset Link'}
          </Button>
        </form>
      ) : (
        <div className="bg-primary-900/30 border border-primary-500/20 p-6 rounded-xl text-center">
          <p className="text-primary-100 mb-4">We've sent a password reset link to <strong>{email}</strong>.</p>
          <p className="text-sm text-slate-400">Please check your inbox and spam folder.</p>
        </div>
      )}
    </div>
  );
};

export default ForgotPasswordPage;
