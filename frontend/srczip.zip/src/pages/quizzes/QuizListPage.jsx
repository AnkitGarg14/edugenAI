import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { quizApi } from '../../services/quizApi';
import { BookOpen, BrainCircuit, Calendar, Trash2, ArrowRight } from 'lucide-react';

const QuizListPage = () => {
  const [quizzes, setQuizzes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchQuizzes();
  }, []);

  const fetchQuizzes = async () => {
    try {
      setLoading(true);
      const data = await quizApi.getQuizzes();
      setQuizzes(data);
    } catch (error) {
      console.error('Failed to fetch quizzes:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (e, id) => {
    e.preventDefault(); // Prevent link click
    if (window.confirm('Are you sure you want to delete this quiz?')) {
      try {
        await quizApi.deleteQuiz(id);
        setQuizzes(quizzes.filter(q => q._id !== id));
      } catch (error) {
        console.error('Failed to delete quiz:', error);
      }
    }
  };

  if (loading) {
    return <div className="p-8 text-center text-slate-500">Loading your quizzes...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-light-text dark:text-dark-text flex items-center gap-3">
            <BrainCircuit className="text-primary" size={32} />
            My Quizzes
          </h1>
          <p className="text-slate-500 mt-2">Review your past quizzes and see your scores.</p>
        </div>
      </div>

      {quizzes.length === 0 ? (
        <div className="glass-panel p-12 text-center flex flex-col items-center">
          <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mb-4">
            <BookOpen className="text-slate-400" size={32} />
          </div>
          <h2 className="text-xl font-bold text-light-text dark:text-dark-text mb-2">No Quizzes Yet</h2>
          <p className="text-slate-500 max-w-md mx-auto mb-6">
            Generate quizzes using the AI Tutor to test your knowledge on any topic or uploaded document.
          </p>
          <Link to="/tutor" className="btn-primary">
            Go to AI Tutor
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quizzes.map((quiz) => {
            const bestScore = quiz.attempts && quiz.attempts.length > 0 
              ? Math.max(...quiz.attempts.map(a => a.score))
              : null;
            
            return (
              <Link key={quiz._id} to={`/quizzes/${quiz._id}`} className="block group">
                <div className="glass-panel h-full p-6 transition-all duration-300 hover:shadow-lg hover:border-primary/50 flex flex-col">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex gap-2">
                      <span className="px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider bg-primary/10 text-primary rounded-full">
                        {quiz.quizType === 'mixed' ? 'Mixed' : quiz.quizType}
                      </span>
                      <span className={`px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider rounded-full ${
                        quiz.difficulty === 'easy' ? 'bg-emerald-500/10 text-emerald-500' :
                        quiz.difficulty === 'hard' ? 'bg-rose-500/10 text-rose-500' :
                        'bg-amber-500/10 text-amber-500'
                      }`}>
                        {quiz.difficulty}
                      </span>
                    </div>
                    <button 
                      onClick={(e) => handleDelete(e, quiz._id)}
                      className="text-slate-400 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                  
                  <h3 className="text-lg font-bold text-light-text dark:text-dark-text mb-2 line-clamp-2">
                    {quiz.topic}
                  </h3>
                  
                  <div className="mt-auto pt-4 border-t border-gray-100 dark:border-slate-800 flex items-center justify-between">
                    <div className="flex items-center text-xs text-slate-500 gap-1.5">
                      <Calendar size={14} />
                      {new Date(quiz.createdAt).toLocaleDateString()}
                    </div>
                    {bestScore !== null ? (
                      <div className="font-semibold text-emerald-500">
                        Score: {bestScore}
                      </div>
                    ) : (
                      <div className="text-sm font-medium text-primary flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                        Take Quiz <ArrowRight size={16} />
                      </div>
                    )}
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default QuizListPage;
