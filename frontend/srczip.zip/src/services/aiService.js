import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const apiClient = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor to add auth token
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const aiService = {
  getChats: async () => {
    const response = await apiClient.get('/ai/chats');
    return response.data;
  },
  
  getMessages: async (chatId) => {
    const response = await apiClient.get(`/ai/chats/${chatId}/messages`);
    return response.data;
  },

  askQuestion: async (chatId, question, documentIds = [], action = null) => {
    const response = await apiClient.post('/ai/ask', {
      chatId,
      question,
      documentIds,
      action
    });
    return response.data;
  }
};
